/*
pivot accepts an array, starting index, and ending index
You can assume the pivot is always the first element
*/

function pivot(){}

/*
quickSort accepts an array, left index, and right index
*/

function quickSort() {}

module.exports = quickSort;